<?php
return array (
	'server' => 'http://%host%/ae_server/srv_main.php',
	'client_name' => '%client_name%',
	'client_pwd' => '%client_pwd%',
);
?>
